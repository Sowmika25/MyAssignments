package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.login;

public class RunCreateAccount extends BaseClass {
	@BeforeTest
	public void setValues() {
		testDescription="Successfully create the account";
		testName="CreateAccount";
		testAuthor="Sowmika";
		testCategory="sanity";
	}
	@Test
	public void runcreateacc() throws IOException {
		login l = new login();
		l.enterUname().enterPwd().clickLogin().clickCrmsfa().clickAccounts().clickCreateAcc().createAcc().getPageTitle();
		
	}
}
