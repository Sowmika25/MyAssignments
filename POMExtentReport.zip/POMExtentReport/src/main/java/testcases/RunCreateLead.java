package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.login;

public class RunCreateLead extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		testDescription="Successfully create the lead";
		testName="CreateLead";
		testAuthor="Sowmika";
		testCategory="smoke";
		
		
		
				
	}
	@Test
	public void runCreateLead() throws IOException {
		
		login l=new login();
		l.enterUname().enterPwd().clickLogin().clickCrmsfa().clickLeads().createLead().entercName()
		.enterfName().enterlName().clickSubmit().verifyLeads();
		
	}

}