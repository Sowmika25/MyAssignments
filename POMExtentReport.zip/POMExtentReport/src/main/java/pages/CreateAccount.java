package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class CreateAccount extends BaseClass {

	public ViewAccDetails createAcc() throws IOException {
		try {
			driver.findElement(By.xpath("//input[@id='accountName']")).sendKeys("Varshini12");
			reportStep("account name enetered successfully","pass");
		} catch (Exception e) {
			reportStep("account name not enetered successfully","fail");
		}
		try {
			driver.findElement(By.xpath("//input[@value='Create Account']")).click();
			reportStep("create account button clicked successfully","pass");
		} catch (Exception e) {
			reportStep("create account button not clicked successfully","fail");
		}
		return new ViewAccDetails();
	}
}
