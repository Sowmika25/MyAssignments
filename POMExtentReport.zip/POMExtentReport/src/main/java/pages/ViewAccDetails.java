package pages;

import base.BaseClass;

public class ViewAccDetails extends BaseClass {

	public ViewAccDetails getPageTitle() {
		String title = driver.getTitle();
		if(title.contains("Account Details")) {
			System.out.println("Title displayed successfully");
		}
		else {
			System.out.println("Title not displayed successfully");
		}
		
		return this;
		
	}
}
