package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyLeads extends BaseClass {
	public CreateLead createLead() throws IOException {
		try {
			driver.findElement(By.linkText("Create Lead")).click();
			reportStep("create leads clicked successfully","pass");
		} catch (Exception e) {
			reportStep("create leads not clicked successfully","fail");
		}
		return new CreateLead();
	}

}