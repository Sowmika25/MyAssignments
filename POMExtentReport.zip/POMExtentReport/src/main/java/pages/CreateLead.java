package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class CreateLead extends BaseClass {
	
public CreateLead entercName() throws IOException {
	try {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TEstleaf");
		reportStep("company name entered successfully","pass");
	} catch (Exception e) {
		reportStep("company name not entered successfully","fail");
	}
	return this;
	
}
public CreateLead enterfName() throws IOException {
	try {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("saranya");
		reportStep("first name entered successfully","pass");
	} catch (Exception e) {
		reportStep("first name not entered successfully","fail");
	}
	return this;
	
}
public CreateLead enterlName() throws IOException {
	try {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("S");
		reportStep("last name entered successfully","pass");
	} catch (Exception e) {
		reportStep("last name not entered successfully","fail");
	}
	return this;
	
}
public ViewLeads clickSubmit() throws IOException {
	try {
		driver.findElement(By.name("submitButton")).click();
		reportStep("submit button clicked successfully","pass");
	} catch (Exception e) {
		reportStep("submit button not clicked successfully","pass");
	}
	return new ViewLeads();
	
}
}