package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyAccounts extends BaseClass {

	public CreateAccount clickCreateAcc() throws IOException {
		try {
			driver.findElement(By.xpath("//a[text()='Create Account']")).click();
			reportStep("create account clicked successfully","pass");
		} catch (Exception e) {
			reportStep("create account not clicked successfully","fail");
		}
		return new CreateAccount();
	}
}
