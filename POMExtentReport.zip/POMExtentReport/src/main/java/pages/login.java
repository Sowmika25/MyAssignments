package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class login extends BaseClass{
	
	public login enterUname() throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys("demosalesmanager");
			reportStep("username entered successfully","pass");
		} catch (Exception e) {
			reportStep("username not entered successfully","fail");
		}
		
		return this;
		
		
	}
	public login enterPwd() throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys("crmsfa");
			reportStep("pwd entered successfully","pass");
		} catch (Exception e) {
			reportStep("pwd not entered successfully","fail");
		}
		return this;
		
	}
	public WelcomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("logged in successfully","pass");
		} catch (Exception e) {
			reportStep("Not logged in successfully","fail");
		}
		return new WelcomePage();
		
	}

}
