package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class WelcomePage extends BaseClass {
	public Homepage clickCrmsfa() throws IOException {
		try {
			driver.findElement(By.linkText("CRM/SFA")).click();
			reportStep("crmsfa clicked successfully","pass");
		} catch (Exception e) {
			reportStep("crmsfa not successfully","fail");
		}
		return new Homepage();
	}
	}

