package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;

public class Homepage extends BaseClass{
	public MyLeads clickLeads() throws IOException {
		try {
			driver.findElement(By.linkText("Leads")).click();
			reportStep("leads clicked successfully","pass");
		} catch (Exception e) {
			reportStep("leads not clicked successfully","fail");
		}
		return new MyLeads();
	}
	
	public MyAccounts clickAccounts() throws IOException {
		try {
			driver.findElement(By.xpath("//a[text()='Accounts']")).click();
			reportStep("accounts clicked successfully","pass");
		} catch (Exception e) {
			reportStep("accounts not clicked successfully","fail");
		}
		return new MyAccounts();
	}

}