package pages;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewAccDetails extends BaseClass {

	@Then("view accounts page is displayed")
	public ViewAccDetails getPageTitle() {
		String title = getDriver().getTitle();
		if(title.contains("Account Details")) {
			System.out.println("Title displayed successfully");
		}
		else {
			System.out.println("Title not displayed successfully");
		}
		
		return this;
		
	}
}
