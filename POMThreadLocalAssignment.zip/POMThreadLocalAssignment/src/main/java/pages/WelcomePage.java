package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	@When("Click on crmsfa link")
	public Homepage clickCrmsfa() throws IOException {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
            return new Homepage();
	}
	}

