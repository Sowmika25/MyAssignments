package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyLeads extends BaseClass {
	
	@When("click on createlead link")
	public CreateLead createLead() throws IOException {
			getDriver().findElement(By.linkText("Create Lead")).click();
			return new CreateLead();
	}

}