package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyAccounts extends BaseClass {

	@When("click on createaccount link")
	public CreateAccount clickCreateAcc() throws IOException {
		getDriver().findElement(By.xpath("//a[text()='Create Account']")).click();
	    return new CreateAccount();
	}
}
