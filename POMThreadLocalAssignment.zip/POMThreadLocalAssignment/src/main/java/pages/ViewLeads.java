package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeads extends BaseClass{
	
	
	@Then("view leads page is displayed")
	public ViewLeads verifyLeads() {
		String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		if (text.contains("saranya")) {
			System.out.println("text matched");
			
		} else {
			System.out.println("text not matched");

		}
		return this;
	}

}