package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class Homepage extends BaseClass{
	
	@When("click on leads link")
	public MyLeads clickLeads() throws IOException {
       getDriver().findElement(By.linkText("Leads")).click();
		return new MyLeads();
	}
	
	@When("click on accounts link")
	public MyAccounts clickAccounts() throws IOException {
			getDriver().findElement(By.xpath("//a[text()='Accounts']")).click();
			return new MyAccounts();
	}

}