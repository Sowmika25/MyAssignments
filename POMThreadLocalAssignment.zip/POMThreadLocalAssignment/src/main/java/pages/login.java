package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class login extends BaseClass{
	@When("Enter the username as {string}")
	public login enterUname(String uname) throws IOException {
			getDriver().findElement(By.id("username")).sendKeys(uname);
			return this;
		}
	@When ("Enter the password as {string}")
	public login enterPwd(String pwd) throws IOException {
	   getDriver().findElement(By.id("password")).sendKeys(pwd);
		return this;
		
	}
   @Then ("Click on the login button")
	public WelcomePage clickLogin() throws IOException {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			return new WelcomePage();
		
	}

}
