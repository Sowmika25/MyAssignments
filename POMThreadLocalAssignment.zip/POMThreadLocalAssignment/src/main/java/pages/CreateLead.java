package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class CreateLead extends BaseClass {
	@When("Enter the company name as (.*)$")	
    public CreateLead entercName(String cname) throws IOException {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
	    return this;
	
     }
	
	@When("enter the first name as (.*)$")
    public CreateLead enterfName(String fname) throws IOException {
    getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
	return this;
	}
	
	@When("Enter the last name as (.*)$")
    public CreateLead enterlName(String lname) throws IOException {
	getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
	return this;
	}
	
	@When("click on the leads button")
    public ViewLeads clickSubmit() throws IOException {
    getDriver().findElement(By.name("submitButton")).click();
	return new ViewLeads();
	}
}