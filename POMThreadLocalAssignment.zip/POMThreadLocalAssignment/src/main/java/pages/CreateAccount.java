package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class CreateAccount extends BaseClass {

	@When("Enter the accountname as (.*)$")
	public CreateAccount enteraccname(String accname) throws IOException {
		
			getDriver().findElement(By.xpath("//input[@id='accountName']")).sendKeys(accname);
			return this;
	}
	
	@When("click on the create account button")
	public ViewAccDetails clickCreateAcc() {
		getDriver().findElement(By.xpath("//input[@value='Create Account']")).click();
		return new ViewAccDetails();
	}
}
